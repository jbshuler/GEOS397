

function [ crust, mantle, core ] = earthLayers

crust = 35;
mantle = 2850;
core = 3486;

end

